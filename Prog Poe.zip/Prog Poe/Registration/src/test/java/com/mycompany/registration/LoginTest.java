/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.registration;

import static org.junit.jupiter.api.Assertions.assertEquals;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;
/**
 *
 * @author Student
 */
public class LoginTest {
    
     @Test
    public void testCheckUserNameValid() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976");
        assertTrue(login.checkUserName());
    }

    @Test
    public void testCheckUserNameInvalid() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyle!!!!!!!",
                "Ch&cK@ke99!",
                "+27838968976");
        assertFalse(login.checkUserName());
    }

    @Test
    public void testCheckPasswordComplexityValid() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976");
        assertTrue(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckPasswordComplexityInvalid() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "power",
                "+27838968976");
        assertFalse(login.checkPasswordComplexity());
    }

    @Test
    public void testCheckCellPhoneNumberValid() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976");
        assertTrue(login.checkCellPhoneNumber());
    }

    @Test
    public void testCheckCellPhoneNumberInvalid() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "0838968976");
        assertFalse(login.checkCellPhoneNumber());
    }

    @Test
    public void testLoginSuccessful() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976");

        assertTrue(
                login.loginUser("kyl_1", "Ch&cK@ke99!")
        );
    }

    @Test
    public void testLoginFailed() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976");

        assertFalse(login.loginUser("wrong_username", "wrong_password"));
    }

    @Test
    public void testReturnLoginStatusSuccessful() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976");

        login.loginUser("kyl_1", "Ch&cK@ke99!");

        assertTrue(
                login.returnLoginStatus().contains("Welcome")
        );
    }

    @Test
    public void testReturnLoginStatusFailed() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976"
        );

        login.loginUser("wrong_username", "wrong_password");

        assertTrue(
                login.returnLoginStatus().contains("Username or password incorrect")
        );
    }

    // 7. Test successful registration
    @Test
    public void testRegisterUserSuccessful() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "+27838968976");

        String result = login.registerUser();

        assertEquals("User successfully registered.", result);
    }

    @Test
    public void testRegisterUserIncorrectUsername() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyle!!!!!!!",
                "Ch&cK@ke99!",
                "+27838968976");

        String result = login.registerUser();

        assertTrue(result.contains("Username is not correctly formatted"));
    }

    @Test
    public void testRegisterUserIncorrectPassword() {

        Login login = new Login(
                "Tshenolo",
                "Ramoshu",
                "kyl_1",
                "power",
                "+27838968976"
        );

        String result = login.registerUser();

        assertTrue(result.contains("Password is not correctly formatted"));
    }

    @Test
    public void testRegisterUserIncorrectCellPhone() {

        Login login = new Login(
                "Tshenolo",
               "Ramoshu",
                "kyl_1",
                "Ch&cK@ke99!",
                "08966553");
        

        String result = login.registerUser();

        assertTrue(result.contains("Cell phone number incorrectly formatted"));
    }
    
}
