/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.registration;

import java.io.File;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Student
 */
public class RegistrationIT {
    
    private MessageReport report;

    private static final String MSG1 = "Did you get the cake?";
    private static final String MSG2 = "Where are you? You are late! I have asked you to be on time.";
    private static final String MSG3 = "Yohoooo, I am at your gate.";
    private static final String MSG4 = "It is dinner time !";
    private static final String MSG5 = "Ok, I am leaving without you.";

    @BeforeEach
    public void setUp() {
        Message.resetForTesting();
        report = new MessageReport();

        Message m1 = new Message("1000000001", 1, "+27834557896", MSG1);
        m1.sentMessage(Message.OPTION_SEND);
        report.recordMessage(m1);

        Message m2 = new Message("1000000002", 2, "+27838884567", MSG2);
        m2.sentMessage(Message.OPTION_STORE);
        report.recordMessage(m2);

        Message m3 = new Message("1000000003", 3, "+27834484567", MSG3);
        m3.sentMessage(Message.OPTION_DISREGARD);
        report.recordMessage(m3);

        Message m4 = new Message("1000000004", 4, "0838884567", MSG4);
        m4.sentMessage(Message.OPTION_SEND);
        report.recordMessage(m4);

        Message m5 = new Message("1000000005", 5, "+27838884567", MSG5);
        m5.sentMessage(Message.OPTION_STORE);
        report.recordMessage(m5);
    }

    @Test
    public void testSentMessagesArrayCorrectlyPopulated() {
        assertArrayEquals(new String[]{MSG1, MSG4}, report.getSentMessagesArray());
    }

    @Test
    public void testDisplayLongestMessage() {
        assertEquals(MSG2, report.displayLongestStoredMessage());
    }

    @Test
    public void testSearchForMessageId() {
        assertEquals("Recipient: +27838884567\nMessage: " + MSG2, report.searchByMessageId("1000000002"));
    }

    @Test
    public void testSearchAllMessagesStoredForRecipient() {
        assertEquals(MSG2 + "\n" + MSG5, report.searchStoredByRecipient("+27838884567"));
    }

    @Test
    public void testDeleteMessageUsingMessageHash() {
        String hashToDelete = report.getStoredMessageHash(0);
        assertEquals("Message: \"" + MSG2 + "\" successfully deleted.", report.deleteByMessageHash(hashToDelete));
        assertEquals(1, report.getStoredCount());
    }

    @Test
    public void testDisplayReportShowsSentMessagesDetails() {
        String sentReport = report.displaySentMessagesReport();
        assertTrue(sentReport.contains("+27834557896"));
        assertTrue(sentReport.contains(MSG1));
        assertTrue(sentReport.contains("0838884567"));
        assertTrue(sentReport.contains(MSG4));
    }

    @Test
    public void testLoadStoredMessagesFromJsonIntoArray() {
        String tempFile = "test_part3_stored.json";
        new File(tempFile).delete();

        Message stored = new Message("2000000001", 1, "+27831112222", "+27838884567", MSG2);
        stored.storeMessage(tempFile);

        MessageReport freshReport = new MessageReport();
        String status = freshReport.loadStoredMessagesFromJson(tempFile);

        assertEquals("1 stored message(s) loaded from " + tempFile + ".", status);
        assertArrayEquals(new String[]{MSG2}, freshReport.getStoredMessagesArray());

        new File(tempFile).delete();
    }
    
}
