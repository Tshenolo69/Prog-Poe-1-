/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;
import java.util.List;
/**
 *
 * @author Student
 */
public class MessageReport {
    private static final int INITIAL_CAPACITY = 10;
// Array of all sent message texts
    private String[] sentMessages;
    private int sentCount;
// Array of all disregarded message texts
    private String[] disregardedMessages;
    private int disregardedCount;
// Parallel arrays for stored messages (matching index represents one stored message)
    private String[] storedMessageIds;
    private String[] storedMessageHashes;
    private String[] storedSenders;
    private String[] storedRecipients;
    private String[] storedMessages;
    private int storedCount;
// Array of all message hashes
    private String[] allMessageHashes;
    private int allHashCount;
// Array of all message IDs
    private String[] allMessageIds;
    private int allIdCount;

    public MessageReport() {
        this.sentMessages = new String[INITIAL_CAPACITY];
        this.disregardedMessages = new String[INITIAL_CAPACITY];
        this.storedMessageIds = new String[INITIAL_CAPACITY];
        this.storedMessageHashes = new String[INITIAL_CAPACITY];
        this.storedSenders = new String[INITIAL_CAPACITY];
        this.storedRecipients = new String[INITIAL_CAPACITY];
        this.storedMessages = new String[INITIAL_CAPACITY];
        this.allMessageHashes = new String[INITIAL_CAPACITY];
        this.allMessageIds = new String[INITIAL_CAPACITY];
    }
//Records a message into the ID/hash arrays and the matching status array
    public void recordMessage(Message msg) {
        if (msg == null) {
            return;
        }

        addMessageId(msg.getMessageID());
        addMessageHash(msg.getMessageHash());

        String status = msg.getStatus();
        if ("sent".equalsIgnoreCase(status)) {
            addSentMessage(msg.getMessageText());
        } else if ("disregarded".equalsIgnoreCase(status)) {
            addDisregardedMessage(msg.getMessageText());
        } else if ("stored".equalsIgnoreCase(status)) {
            addStoredMessage(
                    msg.getMessageID(),
                    msg.getMessageHash(),
                    msg.getSender(),
                    msg.getRecipient(),
                    msg.getMessageText()
            );
        }
    }
//Loads stored messages from the JSON file into the stored parallel arrays
    public String loadStoredMessagesFromJson(String fileName) {
        List<Message> loaded = Message.loadFromJsonFile(fileName);
        for (Message m : loaded) {
            addMessageId(m.getMessageID());
            addMessageHash(m.getMessageHash());
            addStoredMessage(
                    m.getMessageID(),
                    m.getMessageHash(),
                    m.getSender(),
                    m.getRecipient(),
                    m.getMessageText()
            );
        }
        return loaded.size() + " stored message(s) loaded from " + fileName + ".";
    }
//Displays the sender and recipient of all stored messages
    public String displayStoredSendersAndRecipients() {
        if (storedCount == 0) {
            return "No stored messages available.";
        }
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < storedCount; i++) {
            String senderDisplay = (storedSenders[i] == null || storedSenders[i].isEmpty())
                    ? "System/User" : storedSenders[i];
            sb.append("Sender: ").append(senderDisplay)
              .append(" | Recipient: ").append(storedRecipients[i]).append("\n");
        }
        return sb.toString().trim();
    }
//Finds and returns the longest stored message
    public String displayLongestStoredMessage() {
        if (storedCount == 0) {
            return "No stored messages available.";
        }
        String longest = storedMessages[0];
        for (int i = 1; i < storedCount; i++) {
            if (storedMessages[i].length() > longest.length()) {
                longest = storedMessages[i];
            }
        }
        return longest;
    }
//Searches stored messages by message ID and returns recipient and message
    public String searchByMessageId(String targetId) {
        for (int i = 0; i < storedCount; i++) {
            if (storedMessageIds[i] != null && storedMessageIds[i].equals(targetId)) {
                return "Recipient: " + storedRecipients[i] + "\nMessage: " + storedMessages[i];
            }
        }
        return "Message ID " + targetId + " not found.";
    }
//Searches stored messages for a specific recipient
    public String searchStoredByRecipient(String recipient) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < storedCount; i++) {
            if (storedRecipients[i] != null && storedRecipients[i].equals(recipient)) {
                sb.append(storedMessages[i]).append("\n");
            }
        }
        if (sb.length() == 0) {
            return "No stored messages found for recipient " + recipient + ".";
        }
        return sb.toString().trim();
    }
//Deletes a stored message matching the given message hash and shifts parallel arrays left
    public String deleteByMessageHash(String hash) {
        int index = -1;
        // Locate target index by message hash
        for (int i = 0; i < storedCount; i++) {
            if (storedMessageHashes[i] != null && storedMessageHashes[i].equalsIgnoreCase(hash)) {
                index = i;
                break;
            }
        }
        if (index == -1) {
            return "Message with hash " + hash + " not found.";
        }

        String deletedText = storedMessages[index];
// Shift remaining elements left across all parallel arrays
        for (int i = index; i < storedCount - 1; i++) {
            storedMessageIds[i] = storedMessageIds[i + 1];
            storedMessageHashes[i] = storedMessageHashes[i + 1];
            storedSenders[i] = storedSenders[i + 1];
            storedRecipients[i] = storedRecipients[i + 1];
            storedMessages[i] = storedMessages[i + 1];
        }
//// Null out trailing duplicate entry and decrement active count
        storedMessageIds[storedCount - 1] = null;
        storedMessageHashes[storedCount - 1] = null;
        storedSenders[storedCount - 1] = null;
        storedRecipients[storedCount - 1] = null;
        storedMessages[storedCount - 1] = null;
        storedCount--;

        return "Message: \"" + deletedText + "\" successfully deleted.";
    }
//Displays full details of all stored messages
    public String displayStoredMessagesReport() {
        if (storedCount == 0) {
            return "No stored messages to display.";
        }
        StringBuilder sb = new StringBuilder("STORED MESSAGES REPORT\n");
        for (int i = 0; i < storedCount; i++) {
            String senderDisplay = (storedSenders[i] == null || storedSenders[i].isEmpty())
                    ? "System/User" : storedSenders[i];
            sb.append("-----------------------------\n")
              .append("Message ID: ").append(storedMessageIds[i]).append("\n")
              .append("Message Hash: ").append(storedMessageHashes[i]).append("\n")
              .append("Sender: ").append(senderDisplay).append("\n")
              .append("Recipient: ").append(storedRecipients[i]).append("\n")
              .append("Message: ").append(storedMessages[i]).append("\n");
        }
        sb.append("-----------------------------\nTotal stored messages: ").append(storedCount);
        return sb.toString();
    }
//Displays a report of all sent messages (Message Hash, Recipient, Message)
    public String displaySentMessagesReport() {
        List<Message> sentList = Message.getSentMessagesSnapshot();
        if (sentList.isEmpty()) {
            return "No sent messages to display.";
        }
        StringBuilder sb = new StringBuilder("SENT MESSAGES REPORT\n");
        for (Message m : sentList) {
            sb.append("-----------------------------\n")
              .append("Message Hash: ").append(m.getMessageHash()).append("\n")
              .append("Recipient: ").append(m.getRecipient()).append("\n")
              .append("Message: ").append(m.getMessageText()).append("\n");
        }
        return sb.toString().trim();
    }

    private void addSentMessage(String text) {
        if (sentCount == sentMessages.length) {
            sentMessages = grow(sentMessages);
        }
        sentMessages[sentCount++] = text;
    }

    private void addDisregardedMessage(String text) {
        if (disregardedCount == disregardedMessages.length) {
            disregardedMessages = grow(disregardedMessages);
        }
        disregardedMessages[disregardedCount++] = text;
    }

    private void addStoredMessage(String id, String hash, String sender, String recipient, String text) {
        if (storedCount == storedMessages.length) {
            storedMessageIds = grow(storedMessageIds);
            storedMessageHashes = grow(storedMessageHashes);
            storedSenders = grow(storedSenders);
            storedRecipients = grow(storedRecipients);
            storedMessages = grow(storedMessages);
        }
        storedMessageIds[storedCount] = id;
        storedMessageHashes[storedCount] = hash;
        storedSenders[storedCount] = sender;
        storedRecipients[storedCount] = recipient;
        storedMessages[storedCount] = text;
        storedCount++;
    }

    private void addMessageHash(String hash) {
        if (hash == null) {
            return;
        }
        if (allHashCount == allMessageHashes.length) {
            allMessageHashes = grow(allMessageHashes);
        }
        allMessageHashes[allHashCount++] = hash;
    }

    private void addMessageId(String id) {
        if (id == null) {
            return;
        }
        if (allIdCount == allMessageIds.length) {
            allMessageIds = grow(allMessageIds);
        }
        allMessageIds[allIdCount++] = id;
    }
// Doubles array capacity when full
    private String[] grow(String[] original) {
        String[] bigger = new String[original.length * 2];
        System.arraycopy(original, 0, bigger, 0, original.length);
        return bigger;
    }

    public String[] getSentMessagesArray() {
        String[] copy = new String[sentCount];
        System.arraycopy(sentMessages, 0, copy, 0, sentCount);
        return copy;
    }

    public String[] getDisregardedMessagesArray() {
        String[] copy = new String[disregardedCount];
        System.arraycopy(disregardedMessages, 0, copy, 0, disregardedCount);
        return copy;
    }

    public String[] getStoredMessagesArray() {
        String[] copy = new String[storedCount];
        System.arraycopy(storedMessages, 0, copy, 0, storedCount);
        return copy;
    }

    public String[] getMessageHashesArray() {
        String[] copy = new String[allHashCount];
        System.arraycopy(allMessageHashes, 0, copy, 0, allHashCount);
        return copy;
    }

    public String[] getMessageIdsArray() {
        String[] copy = new String[allIdCount];
        System.arraycopy(allMessageIds, 0, copy, 0, allIdCount);
        return copy;
    }

    public String getStoredMessageHash(int index) {
        return storedMessageHashes[index];
    }

    public int getStoredCount() {
        return storedCount;
    }
}
