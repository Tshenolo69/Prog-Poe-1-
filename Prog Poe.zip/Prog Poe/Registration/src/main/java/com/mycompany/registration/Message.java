/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
/**
 *
 * @author Student
 */
class Message {
    // Menu choice constants for handling a completed message
      public static final int OPTION_SEND = 1;
    public static final int OPTION_DISREGARD = 2;
    public static final int OPTION_STORE = 3;
// Default JSON file path used to persist stored messages
    private static final String STORE_FILE = "storedMessages.json";
    private static int nextMessageNumber = 0;
    private static int totalMessagesSent = 0;
    private static final List<Message> sentMessages = new ArrayList<>();
    private static final List<Message> disregardedMessages = new ArrayList<>();

    private final String messageID;
    private final int messageNumber;
    private final String sender;
    private final String recipient;
    private final String messageText;
    private String messageHash;
    private String status;
// Tracks whether message was "sent", "stored", or "disregarded"
    public Message(String recipient, String messageText) {
        this(generateMessageID(), nextMessageNumber++, "", recipient, messageText);
    }
// Auto-generates ID and message number without explicit sender
    public Message(String sender, String recipient, String messageText) {
        this(generateMessageID(), nextMessageNumber++, sender, recipient, messageText);
    }
// Auto-generates ID and message number with sender details
    public Message(String messageID, int messageNumber, String recipient, String messageText) {
        this(messageID, messageNumber, "", recipient, messageText);
    }
// Explicit-ID constructor for unit tests without sender
    public Message(String messageID, int messageNumber, String sender, String recipient, String messageText) {
        this.messageID = messageID;
        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageHash = createMessageHash();
    }
// Generates a random 10-digit numeric ID string
    private static String generateMessageID() {
        Random random = new Random();
        StringBuilder id = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            id.append(random.nextInt(10));
        }
        return id.toString();
    }
//Checks that the message ID is non-null and no more than 10 characters long
    public boolean checkMessageID() {
        return messageID != null && messageID.length() <= 10;
    }
//Returns the confirmation text showing the generated message ID
    public String getMessageIDGeneratedText() {
        return "Message ID generated: " + messageID;
    }
// Validates that the recipient number starts with +27 followed by 9 digits
    public String checkRecipientCell() {
        boolean valid = recipient != null && recipient.matches("^\\+27\\d{9}$");
        if (valid) {
            return "Cell phone number successfully captured.";
        }
        return "Cell phone number is incorrectly formatted or does not contain an "
                + "international code. Please correct the number and try again.";
    }
//Checks that the message length is within the 250-character limit
    public String checkMessageLength() {
        if (messageText == null) {
            return "Message exceeds 250 characters by 250; please reduce the size.";
        }
        int over = messageText.length() - 250;
        if (over > 0) {
            return "Message exceeds 250 characters by " + over + "; please reduce the size.";
        }
        return "Message ready to send.";
    }
//Creates the uppercase message hash using the first 2 digits of the ID,
     // the message number, and the first and last words of the message
    public final String createMessageHash() {
        String idPart = (messageID != null && messageID.length() >= 2)
                ? messageID.substring(0, 2) : String.valueOf(messageID);
        String[] words = (messageText == null ? "" : messageText.trim()).split("\\s+");
        String first = words.length > 0 ? stripPunctuation(words[0]).toUpperCase() : "";
        String last = words.length > 0 ? stripPunctuation(words[words.length - 1]).toUpperCase() : "";
        this.messageHash = idPart + ":" + messageNumber + ":" + first + last;
        return messageHash;
    }
// Strips non-alphanumeric characters from word edges so hash words stay clean
    private static String stripPunctuation(String word) {
        return word.replaceAll("[^a-zA-Z0-9]", "");
    }
//Handles sending, disregarding, or storing the message based on user selection
    public String sentMessage(int choice) {
        return sentMessage(choice, STORE_FILE);
    }
//Overload allowing a custom JSON file name (used in tests and main app)
    public String sentMessage(int choice, String fileName) {
        switch (choice) {
            case OPTION_SEND:
                status = "sent";
                totalMessagesSent++;
                sentMessages.add(this);
                return "Message successfully sent.";
            case OPTION_DISREGARD:
                status = "disregarded";
                disregardedMessages.add(this);
                return "Press 0 to delete the message.";
            case OPTION_STORE:
                status = "stored";
                storeMessage(fileName);
                return "Message successfully stored.";
            default:
                return "Invalid option selected.";
        }
    }
//Returns formatted details for all messages sent during the current run
    public static String printMessages() {
        StringBuilder sb = new StringBuilder();
        for (Message m : sentMessages) {
            sb.append("Message ID: ").append(m.messageID).append("\n")
              .append("Message Hash: ").append(m.messageHash).append("\n")
              .append("Recipient: ").append(m.recipient).append("\n")
              .append("Message: ").append(m.messageText).append("\n\n");
        }
        return sb.toString();
    }
//Returns the total number of messages sent
    public static int returnTotalMessagesSent() {
        return totalMessagesSent;
    }
// Returns a defensive copy of sent messages
    public static List<Message> getSentMessagesSnapshot() {
        return new ArrayList<>(sentMessages);
    }
// Returns a defensive copy of disregarded messages
    public static List<Message> getDisregardedMessagesSnapshot() {
        return new ArrayList<>(disregardedMessages);
    }
//Appends this message as a JSON object to the default JSON file
    public void storeMessage() {
        storeMessage(STORE_FILE);
    }
//Appends this message as a JSON object to the specified JSON file
    public void storeMessage(String fileName) {
        appendToJsonFile(fileName, toJson());
    }
//Reads JSON message records from disk into a list for loading into arrays
    public static List<Message> loadFromJsonFile(String fileName) {
        List<Message> loaded = new ArrayList<>();
        try {
            File file = new File(fileName);
            if (!file.exists()) {
                return loaded;
            }
            String content = new String(Files.readAllBytes(file.toPath())).trim();
            if (content.length() <= 2) {
                return loaded;
            }
            // Split top-level JSON objects inside the JSON array
            String[] objects = content.substring(1, content.length() - 1).split("\\},\\s*\\{");
            for (String rawObj : objects) {
                String obj = rawObj.trim();
                if (!obj.startsWith("{")) obj = "{" + obj;
                if (!obj.endsWith("}")) obj = obj + "}";

                String id = extractJsonString(obj, "messageID");
                int num = extractJsonInt(obj, "messageNumber");
                String snd = extractJsonString(obj, "sender");
                String rec = extractJsonString(obj, "recipient");
                String txt = extractJsonString(obj, "message");
                String hash = extractJsonString(obj, "messageHash");

                Message m = new Message(id, num, snd, rec, txt);
                if (!hash.isEmpty()) {
                    m.messageHash = hash;
                }
                m.status = "stored";
                loaded.add(m);
            }
        } catch (IOException ignored) {
        }
        return loaded;
    }

    private String toJson() {
        return "{"
                + "\"messageID\":\"" + escape(messageID) + "\","
                + "\"messageNumber\":" + messageNumber + ","
                + "\"sender\":\"" + escape(sender) + "\","
                + "\"recipient\":\"" + escape(recipient) + "\","
                + "\"message\":\"" + escape(messageText) + "\","
                + "\"messageHash\":\"" + escape(messageHash) + "\""
                + "}";
    }

    private static synchronized void appendToJsonFile(String path, String jsonObject) {
        try {
            File file = new File(path);
            String content = file.exists()
                    ? new String(Files.readAllBytes(file.toPath())).trim()
                    : "[]";
            if (!content.startsWith("[") || !content.endsWith("]")) {
                content = "[]";
            }
            String inner = content.substring(1, content.length() - 1).trim();
            String updated = inner.isEmpty()
                    ? "[\n  " + jsonObject + "\n]"
                    : "[\n" + inner + ",\n  " + jsonObject + "\n]";
            Files.write(file.toPath(), updated.getBytes());
        } catch (IOException e) {
            System.out.println("Could not store message: " + e.getMessage());
        }
    }
// Extracts a string field value from a JSON object snippet
    private static String extractJsonString(String obj, String key) {
        String pattern = "\"" + key + "\":\"";
        int start = obj.indexOf(pattern);
        if (start == -1) return "";
        start += pattern.length();
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < obj.length(); i++) {
            char c = obj.charAt(i);
            if (c == '\\' && i + 1 < obj.length()) {
                char next = obj.charAt(++i);
                if (next == '"') sb.append('"');
                else if (next == '\\') sb.append('\\');
                else sb.append(next);
            } else if (c == '"') {
                break;
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
// Extracts an integer field value from a JSON object snippet
    private static int extractJsonInt(String obj, String key) {
        String pattern = "\"" + key + "\":";
        int start = obj.indexOf(pattern);
        if (start == -1) return 0;
        start += pattern.length();
        int end = start;
        while (end < obj.length() && (Character.isDigit(obj.charAt(end)) || obj.charAt(end) == '-')) {
            end++;
        }
        try {
            return Integer.parseInt(obj.substring(start, end));
        } catch (NumberFormatException e) {
            return 0;
        }
    }
// Escapes quotes and backslashes for valid JSON output
    private static String escape(String s) {
        return s == null ? "" : s.replace("\\", "\\\\").replace("\"", "\\\"");
    }
// Get functions
    public String getMessageID() { return messageID; }
    public int getMessageNumber() { return messageNumber; }
    public String getSender() { return sender; }
    public String getRecipient() { return recipient; }
    public String getMessageText() { return messageText; }
    public String getMessageHash() { return messageHash; }
    public String getStatus() { return status; }
// Clears shared static collections between unit tests
    static void resetForTesting() {
        totalMessagesSent = 0;
        nextMessageNumber = 0;
        sentMessages.clear();
        disregardedMessages.clear();
    }
}
