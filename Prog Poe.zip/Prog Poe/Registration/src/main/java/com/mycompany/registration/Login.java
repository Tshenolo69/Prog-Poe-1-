/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.registration;

/**
 *
 * @author Student
 */
class Login {

   public String firstName;
    public String lastName;
    public String userName;
    public String userPassword;
    public String cellPhoneNumber;
    public boolean loginStatus;
// Constructor initializes user fields and sets initial login state to false
    public Login(String firstName, String lastName, String userName, String userPassword, String cellPhoneNumber) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.userName = userName;
        this.userPassword = userPassword;
        this.cellPhoneNumber = cellPhoneNumber;
        this.loginStatus = false;
    }

     //Ensures the username contains an underscore (_) and is at most 5 characters long[cite: 7, 33, 52].
     
    public boolean checkUserName() {
        return this.userName != null && this.userName.contains("_") && this.userName.length() <= 5;
    }

     // Ensures the password is at least 8 characters long and contains at least one
     // uppercase letter, one digit, and one special character
     
    public boolean checkPasswordComplexity() {
        if (this.userPassword == null) {
            return false;
        }
        boolean hasMinLength = this.userPassword.length() >= 8;
        boolean hasCapital = this.userPassword.matches(".*[A-Z].*");
        boolean hasNumber = this.userPassword.matches(".*[0-9].*");
        boolean hasSpecial = this.userPassword.matches(".*[^a-zA-Z0-9].*");
        return hasMinLength && hasCapital && hasNumber && hasSpecial;
    }

     //Checks that the South African cell phone number starts with +27 followed by 9 digits
     // Reference: Oracle (2026) Java String.matches() regular expression API
     
    public boolean checkCellPhoneNumber() {
        boolean valid = cellPhoneNumber != null && cellPhoneNumber.matches("^\\+27\\d{9}$");
        if (valid) {
            System.out.println("Cell phone number successfully captured.");
            return true;
        } else {
            System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            return false;
        }
    }

     // Runs validation checks in order and returns the matching registration response
     
    public String registerUser() {
        if (!checkUserName()) {
            return "Username is not correctly formatted; please ensure that your username contains an "
                    + "underscore and is no more than five characters in length.";
        } else if (!checkPasswordComplexity()) {
            return "Password is not correctly formatted; please ensure that the password contains at least "
                    + "eight characters, a capital letter, a number, and a special character.";
        } else if (!checkCellPhoneNumber()) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        } else {
            return "User successfully registered.";
        }
    }

     // Verifies whether the entered username and password match the registered account
    
    public boolean loginUser(String enteredUserName, String enteredUserPassword) {
        if (this.userName != null && this.userName.equals(enteredUserName)
                && this.userPassword != null && this.userPassword.equals(enteredUserPassword)) {
            this.loginStatus = true;
        } else {
            this.loginStatus = false;
        }
        return this.loginStatus;
    }

     //Returns the welcome message if logged in, or an authentication error message otherwise
     
    public String returnLoginStatus() {
        if (loginStatus) {
            return "Welcome " + firstName + ", " + lastName + " it is great to see you again.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
    
    
}
