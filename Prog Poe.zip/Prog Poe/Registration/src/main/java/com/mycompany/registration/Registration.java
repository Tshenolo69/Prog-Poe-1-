/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.registration;
import java.util.Scanner;
/**
 *
 * @author Student
 */
public class Registration {

    
       private static final String STORED_FILE = "storedMessages.json";
public static void main(String[] args) {
   
        Scanner input = new Scanner(System.in);

        // =================== PART 1: Registration & Login ===================
        System.out.println("Please enter your first name: ");
        String firstName = input.nextLine();

        System.out.println("Please enter your last name: ");
        String lastName = input.nextLine();

        System.out.println("Your user name should contain an underscore"
                + " and should be no more than 5 characters long:");
        System.out.println("Please enter your UserName: ");
        String userName = input.nextLine();

        System.out.println("Password must contain at least 8 characters, a capital letter, a number, and a special character:");
        System.out.println("Please enter your Password: ");
        String userPassword = input.nextLine();

        System.out.println("Enter your South African cell phone number (e.g. +27831234567): ");
        String cellPhoneNumber = input.nextLine();

        Login login = new Login(firstName, lastName, userName, userPassword, cellPhoneNumber);
        System.out.println(login.registerUser());

        System.out.println("\n--- Login ---");
        System.out.println("Enter your username: ");
        String enteredUserName = input.nextLine();

        System.out.println("Enter your password: ");
        String enteredUserPassword = input.nextLine();

        boolean loggedIn = login.loginUser(enteredUserName, enteredUserPassword);
        System.out.println(login.returnLoginStatus());
// Only allow access to QuickChat if login succeeded
        if (!loggedIn) {
            return;
        }

        // =================== PART 2 & PART 3: QuickChat & Reports ===================
        System.out.println("\nWelcome to QuickChat.");

        MessageReport report = new MessageReport();
        // Load previously stored messages from JSON file into parallel arrays at startup
        System.out.println(report.loadStoredMessagesFromJson(STORED_FILE));

        int numMessages = readInt(input, "How many messages would you like to enter? ");

        boolean running = true;
        // Main application loop runs until option 3 (Quit) is selected
        while (running) {
            System.out.println("\n1) Send Messages");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4) Stored Messages");
            System.out.print("Choose an option: ");
            String choice = input.nextLine().trim();

            switch (choice) {
                case "1":
                    sendMessages(input, numMessages, cellPhoneNumber, report);
                    if (numMessages >= 0) {
                        System.out.println("\nAll " + numMessages + " messages have been entered.");
                        System.out.println("Total messages sent: " + Message.returnTotalMessagesSent());
                    }
                    break;
                case "2":
                    System.out.println("Coming Soon.");
                    break;
                case "3":
                    running = false;
                    break;
                case "4":
                    showStoredMessagesMenu(input, report);
                    break;
                default:
                    System.out.println("Please choose 1, 2, 3 or 4.");
            }
        }
        System.out.println("Goodbye.");
    }
// Sub-menu for Part 3 Option 4 actions
    private static void showStoredMessagesMenu(Scanner input, MessageReport report) {
        boolean inMenu = true;
        while (inMenu) {
            System.out.println("\n--- STORED MESSAGES & REPORTS ---");
            System.out.println("a) Display sender and recipient of all stored messages");
            System.out.println("b) Display longest stored message");
            System.out.println("c) Search for a message ID");
            System.out.println("d) Search stored messages by recipient");
            System.out.println("e) Delete a message using message hash");
            System.out.println("f) Display report of all stored messages");
            System.out.println("g) Back to main menu");
            System.out.print("Choose an option: ");
            String sub = input.nextLine().trim().toLowerCase();

            switch (sub) {
                case "a":
                    System.out.println(report.displayStoredSendersAndRecipients());
                    break;
                case "b":
                    System.out.println("Longest stored message: " + report.displayLongestStoredMessage());
                    break;
                case "c":
                    System.out.print("Enter Message ID: ");
                    System.out.println(report.searchByMessageId(input.nextLine().trim()));
                    break;
                case "d":
                    System.out.print("Enter Recipient cell number: ");
                    System.out.println(report.searchStoredByRecipient(input.nextLine().trim()));
                    break;
                case "e":
                    System.out.print("Enter Message Hash: ");
                    System.out.println(report.deleteByMessageHash(input.nextLine().trim()));
                    break;
                case "f":
                    System.out.println(report.displayStoredMessagesReport());
                    break;
                case "g":
                    inMenu = false;
                    break;
                default:
                    System.out.println("Please choose a valid option (a-g).");
            }
        }
    }
// For loop captures the exact count of messages requested by the user
    private static void sendMessages(Scanner sc, int count, String senderCell, MessageReport report) {
        for (int i = 0; i < count; i++) {
            System.out.println("\n-- New message (" + (i + 1) + " of " + count + ") --");
            System.out.print("Recipient (e.g. +27831234567): ");
            String recipient = sc.nextLine();
            System.out.print("Message: ");
            String text = sc.nextLine();

            Message message = new Message(senderCell, recipient, text);

            String cellResult = message.checkRecipientCell();
            System.out.println(cellResult);
            boolean cellOk = cellResult.startsWith("Cell phone number successfully");

            String lengthResult = message.checkMessageLength();
            System.out.println(lengthResult);
            boolean lengthOk = "Message ready to send.".equals(lengthResult);

            if (!message.checkMessageID()) {
                System.out.println("Message ID is invalid; discarding this message.");
                continue;
            }
            if (!cellOk || !lengthOk) {
                System.out.println("This message cannot be sent as-is.");
            }

            int option = readInt(sc, "Choose: 1) Send  2) Disregard  3) Store: ");
            System.out.println(message.sentMessage(option, STORED_FILE));
            report.recordMessage(message);
// Display full message details in required order after sending
            if (option == Message.OPTION_SEND) {
                System.out.println("\nMessage ID: " + message.getMessageID());
                System.out.println("Message Hash: " + message.getMessageHash());
                System.out.println("Recipient: " + message.getRecipient());
                System.out.println("Message: " + message.getMessageText());
            }
        }
    }
// Safely reads an integer from console input
    private static int readInt(Scanner sc, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = sc.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }
}
    
    

